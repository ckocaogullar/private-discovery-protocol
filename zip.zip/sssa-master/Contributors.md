Contributors:
    Alexander Scheel - alexander.m.scheel@gmail.com
